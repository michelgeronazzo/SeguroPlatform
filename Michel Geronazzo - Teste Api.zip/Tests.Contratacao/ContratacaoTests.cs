﻿using ContratacaoService.Core.Ports;
using ContratacaoService.Infra;
using Moq;
using PropostaService.Core.Domain;
using Shared.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests.Contratacao
{
    public class ContratacaoTests
    {
        [Fact]
        public async Task Contratar_ComPropostaAprovada_DeveCriarContratacao()
        {
            var repo = new InMemoryContratacaoRepository();
            var mockRemote = new Mock<IPropostaRemotePort>();
            var proposta = new Proposta { Id = Guid.NewGuid(), Proponente = "A", Valor = 100m, Status = PropostaStatus.Aprovada };
            mockRemote.Setup(x => x.ObterPropostaAsync(proposta.Id)).ReturnsAsync(proposta);
            var service = new ContratacaoService.Core.UseCases.ContratacaoService(repo, mockRemote.Object);
            var c = await service.ContratarAsync(proposta.Id);
            Assert.NotNull(c);
            Assert.Equal(proposta.Id, c.PropostaId);
        }

    }
}
