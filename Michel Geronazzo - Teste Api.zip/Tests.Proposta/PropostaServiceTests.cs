﻿using PropostaService.Infra;
using PropostaService.Infra.InMemory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests.Proposta
{
    public class PropostaServiceTests
    {
        [Fact]
        public async Task CriarProposta_DeveSalvar()
        {
            var repo = new InMemoryPropostaRepository();
            var service = new PropostaService.Core.UseCases.PropostaService(repo);
            var p = await service.CriarAsync("Joao", 1000m);
            var all = await repo.GetAllAsync();
            Assert.Contains(all, x => x.Id == p.Id && x.Proponente == "Joao");
        }
    }
}
